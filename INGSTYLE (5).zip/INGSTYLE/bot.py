import re
import threading
from datetime import datetime, timedelta

import telebot
from telebot import types

import analyzer
import db_handler

BOT_TOKEN = "8530439375:AAFEZOcpatuh0NK6Ub92TD8_ehPc3IZNxCo"
if not BOT_TOKEN:
    raise RuntimeError("Не задан BOT_TOKEN. Укажите переменную окружения BOT_TOKEN.")

bot = telebot.TeleBot(BOT_TOKEN)
timers: dict[int, threading.Timer] = {}
fsm: dict[int, dict] = {}

BTN = "➕ Записать день", "📊 Статистика", "📋 История", "⚙️ Настройки"
MAIN_KB = types.ReplyKeyboardMarkup(resize_keyboard=True)
MAIN_KB.row(*BTN[:2])
MAIN_KB.row(*BTN[2:])

MOOD = {f"mood_{i}": i for i in range(1, 6)}
TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")

STATS = {
    "stats_week": lambda u: analyzer.period_summary(u, 7, "неделю"),
    "stats_month": lambda u: analyzer.period_summary(u, 30, "месяц"),
    "stats_insights": analyzer.generate_insights,
}

COMMANDS = [
    types.BotCommand("start", "Приветствие и инструкция"),
    types.BotCommand("add", "Записать данные за сегодня"),
    types.BotCommand("stats", "Статистика"),
    types.BotCommand("history", "История записей"),
    types.BotCommand("settings", "Время напоминания"),
    types.BotCommand("clear", "Очистить все данные"),
    types.BotCommand("help", "Краткая справка"),
]


def send(cid: int, text: str, **kw):
    kw.setdefault("reply_markup", MAIN_KB)
    bot.send_message(cid, text, **kw)


def ikb(items: list[tuple[str, str]], cols: int = 1):
    kb = types.InlineKeyboardMarkup(row_width=cols)
    kb.add(*[types.InlineKeyboardButton(t, callback_data=d) for t, d in items])
    return kb


def hours_ikb(kind: str):
    presets = {"work": ("0.5", "1", "2", "4"), "sleep": ("6", "7", "8", "9")}
    cols = 3 if kind == "work" else 4
    items = [(f"{v} ч", f"{kind}_{v}") for v in presets[kind]]
    items.append(("Другое...", f"{kind}_other"))
    return ikb(items, cols)


MOOD_KB = ikb([(f"{i} {e}", f"mood_{i}") for i, e in enumerate("😞😐🙂😊🤩", 1)], 5)
STATS_KB = ikb(
    [
        ("📅 За неделю", "stats_week"),
        ("🗓 За месяц", "stats_month"),
        ("🔍 Мои инсайты", "stats_insights"),
        ("📉 График", "stats_chart"),
    ]
)
SKIP_KB = ikb([("Пропустить", "comment_skip")])


def bind(cmd: str, btn: str):
    def deco(fn):
        bot.message_handler(commands=[cmd])(fn)
        bot.message_handler(func=lambda m, b=btn: m.text == b)(fn)
        return fn

    return deco


def st(uid: int) -> str | None:
    return fsm.get(uid, {}).get("state")


def set_st(uid: int, name: str | None = None, **data):
    if name is None:
        fsm.pop(uid, None)
    else:
        fsm.setdefault(uid, {}).update(state=name, **data)


# Напоминания


def secs_until(t: str) -> float:
    now = datetime.now()
    h, m = map(int, t.split(":"))
    target = now.replace(hour=h, minute=m, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    return (target - now).total_seconds()


def remind(uid: int):
    try:
        send(uid, "⏰ Напоминание: не забудь записать день! Нажми «➕ Записать день» или /add")
    except Exception:
        pass


def plan(uid: int, t: str):
    old = timers.pop(uid, None)
    if old:
        old.cancel()

    def tick():
        remind(uid)
        plan(uid, t)

    timer = threading.Timer(secs_until(t), tick)
    timer.daemon = True
    timer.start()
    timers[uid] = timer


# --- Команды ---


@bot.message_handler(commands=["start"])
def cmd_start(m):
    send(
        m.chat.id,
        "Привет! Я трекер настроения и продуктивности.\n\n"
        "Используй кнопки внизу или команды:\n"
        "/add — записать день\n"
        "/stats — статистика\n"
        "/history — последние записи\n"
        "/settings — напоминание\n"
        "/help — справка",
    )


@bot.message_handler(commands=["help"])
def cmd_help(m):
    send(
        m.chat.id,
        "📖 Справка\n\n"
        "/start — приветствие\n"
        "/add — пошаговый ввод за сегодня\n"
        "/stats — неделя, месяц, инсайты, график\n"
        "/history — последние 7 записей\n"
        "/settings — время ежедневного напоминания (ЧЧ:ММ)\n"
        "/clear — удалить все ваши записи\n"
        "/help — эта справка",
    )


@bind("add", BTN[0])
def on_add(m):
    uid, cid = m.from_user.id, m.chat.id
    if db_handler.has_record_today(uid):
        return send(cid, "⚠️ Запись за сегодня уже есть. Можно только одна запись в день.")
    set_st(uid, "mood")
    bot.send_message(
        cid,
        "Оцени свое настроение сегодня от 1 до 5, где 1 — ужасно, 5 — отлично.",
        reply_markup=MOOD_KB,
    )


@bind("stats", BTN[1])
def on_stats(m):
    bot.send_message(m.chat.id, "Что хочешь узнать?", reply_markup=STATS_KB)


@bind("history", BTN[2])
def on_history(m):
    rows = db_handler.get_last_records(m.from_user.id, 7)
    if not rows:
        return send(m.chat.id, "История пуста. Добавь первую запись через /add.")
    body = "\n\n".join(analyzer.format_history_entry(r) for r in reversed(rows))
    send(m.chat.id, f"📋 Последние записи:\n\n{body}")


@bind("settings", BTN[3])
def on_settings(m):
    uid, cid = m.from_user.id, m.chat.id
    hint = db_handler.get_reminder_time(uid)
    hint = f"\n\nТекущее время: {hint}" if hint else ""
    set_st(uid, "settings_time")
    bot.send_message(
        cid,
        f"⚙️ Настройки\n\nВведи время ежедневного напоминания в формате ЧЧ:ММ (например, 21:00).{hint}",
        reply_markup=types.ReplyKeyboardRemove(),
    )


@bot.message_handler(commands=["clear"])
def cmd_clear(m):
    bot.send_message(
        m.chat.id,
        "⚠️ Удалить все твои записи? Это действие нельзя отменить.",
        reply_markup=ikb([("✅ Да, удалить всё", "clear_yes"), ("❌ Отмена", "clear_no")], 2),
    )


# --- Callbacks (один обработчик) ---


@bot.callback_query_handler(func=lambda c: True)
def on_cb(call):
    d, uid, cid = call.data, call.from_user.id, call.message.chat.id
    bot.answer_callback_query(call.id)

    if d in STATS:
        return send(cid, STATS[d](uid))

    if d == "stats_chart":
        chart = analyzer.generate_chart(uid)
        if chart:
            return bot.send_photo(cid, chart, caption="📉 График за последние 7 дней", reply_markup=MAIN_KB)
        return send(cid, "Нет данных за последние 7 дней для графика.")

    if d == "clear_no":
        return send(cid, "Отменено.")
    if d == "clear_yes":
        return send(cid, f"✅ Удалено записей: {db_handler.delete_user_records(uid)}.")

    if d in MOOD and st(uid) == "mood":
        set_st(uid, "work", mood=MOOD[d])
        bot.edit_message_reply_markup(cid, call.message.message_id, reply_markup=None)
        return bot.send_message(cid, "Сколько часов ты потратил на полезную работу/учебу?", reply_markup=hours_ikb("work"))

    if d.startswith("work_") or d.startswith("sleep_"):
        kind = "work" if d.startswith("work_") else "sleep"
        if st(uid) not in (kind, f"{kind}_custom"):
            return
        if d == f"{kind}_other":
            set_st(uid, f"{kind}_custom", **fsm[uid])
            ex = "3.5" if kind == "work" else "7.5"
            return bot.send_message(cid, f"Введи количество часов числом (например, {ex}):")
        hours = float(d[len(kind) + 1 :])
        e = fsm[uid]
        bot.edit_message_reply_markup(cid, call.message.message_id, reply_markup=None)
        if kind == "work":
            set_st(uid, "sleep", mood=e["mood"], work_hours=hours)
            return bot.send_message(cid, "Сколько часов ты спал?", reply_markup=hours_ikb("sleep"))
        set_st(uid, "comment", mood=e["mood"], work_hours=e["work_hours"], sleep_hours=hours)
        return bot.send_message(
            cid,
            "Хочешь добавить комментарий? (Напиши текст или нажми «Пропустить»)",
            reply_markup=SKIP_KB,
        )

    if d == "comment_skip" and st(uid) == "comment":
        save(cid, uid, None)


def save(cid: int, uid: int, comment: str | None):
    e = fsm.get(uid, {})
    mood, work, sleep = e.get("mood"), e.get("work_hours"), e.get("sleep_hours")
    if None in (mood, work, sleep):
        set_st(uid)
        return send(cid, "Ошибка: данные неполные. Начни заново с /add.")
    if not db_handler.add_record(uid, mood, work, sleep, comment):
        set_st(uid)
        return send(cid, "⚠️ Запись за сегодня уже существует.")
    set_st(uid)
    text = (
        f"✅ Запись сохранена!\n\n"
        f"Настроение: {analyzer.MOOD_EMOJI.get(mood, '')} ({mood}/5)\n"
        f"Работа: {work} ч\nСон: {sleep} ч"
    )
    if comment:
        text += f"\nКомментарий: {comment}"
    send(cid, text)


def parse_hours(text: str) -> float | None:
    try:
        v = float(text.replace(",", ".").strip())
        return v if 0 <= v <= 24 else None
    except ValueError:
        return None


def after_hours(m, kind: str, value: float):
    e = fsm[m.from_user.id]
    if kind == "work":
        set_st(m.from_user.id, "sleep", mood=e["mood"], work_hours=value)
        bot.send_message(m.chat.id, "Сколько часов ты спал?", reply_markup=hours_ikb("sleep"))
    else:
        set_st(m.from_user.id, "comment", mood=e["mood"], work_hours=e["work_hours"], sleep_hours=value)
        bot.send_message(
            m.chat.id,
            "Хочешь добавить комментарий? (Напиши текст или нажми «Пропустить»)",
            reply_markup=SKIP_KB,
        )


@bot.message_handler(content_types=["text"])
def on_text(m):
    uid, cid, text = m.from_user.id, m.chat.id, (m.text or "").strip()
    s = st(uid)

    if s == "settings_time":
        if not TIME_RE.match(text):
            return bot.send_message(cid, "Некорректный формат. Введи время как ЧЧ:ММ (например, 09:30).")
        h, mi = map(int, text.split(":"))
        t = f"{h:02d}:{mi:02d}"
        db_handler.set_reminder_time(uid, t)
        plan(uid, t)
        set_st(uid)
        return send(cid, f"✅ Напоминание установлено на {t} каждый день.")

    if s in ("work_custom", "sleep_custom"):
        v = parse_hours(text)
        if v is None:
            return bot.send_message(cid, "Введи корректное число часов (0–24).")
        return after_hours(m, s.split("_")[0], v)

    if s == "comment":
        return save(cid, uid, text)

    if s in ("mood", "work", "sleep"):
        bot.send_message(cid, "Используй кнопки выше или начни заново с /add.")


def main():
    if not db_handler.DB_PATH.exists():
        db_handler.init_db()
    try:
        bot.set_my_commands(COMMANDS)
    except Exception as e:
        print(f"Предупреждение: меню команд ({type(e).__name__}). Бот продолжит работу.")
    for uid, t in db_handler.get_all_reminder_settings():
        try:
            plan(uid, t)
        except Exception:
            pass
    print("Бот запущен...")
    bot.infinity_polling()


if __name__ == "__main__":
    main()
