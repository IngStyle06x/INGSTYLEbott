"""Статистика, инсайты и генерация графиков."""

import io
from collections import defaultdict
from datetime import date

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from db_handler import get_records_between, period_dates

MOOD_EMOJI = {1: "😞", 2: "😐", 3: "🙂", 4: "😊", 5: "🤩"}
WEEKDAYS = "Понедельник Вторник Среда Четверг Пятница Суббота Воскресенье".split()


def period_summary(user_id: int, days: int, label: str) -> str:
    rows = get_records_between(user_id, *period_dates(days))
    if not rows:
        return f"За {label} нет записей. Добавь данные через /add или «➕ Записать день»."
    data = [dict(r) for r in rows]
    n = len(data)
    moods = [r["mood"] for r in data]
    work = [r["work_hours"] for r in data]
    sleep = [r["sleep_hours"] for r in data]
    best, worst = max(data, key=lambda r: r["mood"]), min(data, key=lambda r: r["mood"])

    def day(r):
        d = date.fromisoformat(r["date"])
        return f"{d.strftime('%d.%m.%Y')} ({MOOD_EMOJI.get(r['mood'], '')} {r['mood']})"

    return (
        f"📊 Сводка {label}\n\n"
        f"• Среднее настроение: {sum(moods) / n:.2f}\n"
        f"• Средние часы работы: {sum(work) / n:.2f} ч\n"
        f"• Средние часы сна: {sum(sleep) / n:.2f} ч\n"
        f"• Лучший день: {day(best)}\n"
        f"• Худший день: {day(worst)}"
    )


def _split(data, key, val):
    med = sorted(r[key] for r in data)[len(data) // 2]
    hi = [r[val] for r in data if r[key] >= med]
    lo = [r[val] for r in data if r[key] < med]
    return hi, lo


def _trend(hi, lo, eps, weak, neg, pos, empty):
    if not hi or not lo:
        return empty
    a, b = sum(hi) / len(hi), sum(lo) / len(lo)
    d = a - b
    if abs(d) < eps:
        return weak(a, b)
    return neg(a, b) if d < 0 else pos(a, b)


def generate_insights(user_id: int) -> str:
    data = [dict(r) for r in get_records_between(user_id, *period_dates(30))]
    if len(data) < 3:
        return "Недостаточно данных для инсайтов. Нужно минимум 3 записи за последние 30 дней."

    by_wd = defaultdict(list)
    for r in data:
        by_wd[date.fromisoformat(r["date"]).weekday()].append(r["mood"])
    avg = {wd: sum(v) / len(v) for wd, v in by_wd.items()}
    b, w = max(avg, key=avg.get), min(avg, key=avg.get)
    i1 = (
        f"Обычно настроение выше в {WEEKDAYS[b]} (среднее {avg[b]:.2f}), "
        f"ниже — в {WEEKDAYS[w]} (среднее {avg[w]:.2f})."
    )

    i2 = _trend(
        *_split(data, "work_hours", "mood"),
        0.15,
        lambda a, b: (
            "Большее количество часов работы/учёбы слабо связано с настроением "
            f"(среднее при высокой нагрузке: {a:.2f}, при низкой: {b:.2f})."
        ),
        lambda a, b: (
            "При большем количестве часов работы/учёбы настроение обычно ниже "
            f"(среднее {a:.2f} vs {b:.2f} при меньшей нагрузке)."
        ),
        lambda a, b: (
            "При большем количестве часов работы/учёбы настроение обычно выше "
            f"(среднее {a:.2f} vs {b:.2f} при меньшей нагрузке)."
        ),
        "Недостаточно разнообразия по часам работы для вывода.",
    )

    i3 = _trend(
        *_split(data, "sleep_hours", "work_hours"),
        0.3,
        lambda a, b: (
            "Связь между часами сна и продуктивностью (часами работы) слабая "
            f"(средняя работа при достаточном сне: {a:.1f} ч, при недосыпе: {b:.1f} ч)."
        ),
        lambda a, b: (
            "При большем количестве сна продуктивность (часы работы) обычно выше "
            f"({a:.1f} ч vs {b:.1f} ч при меньшем сне)."
        ),
        lambda a, b: (
            "При меньшем сне отмечается не меньшая продуктивность по часам работы "
            f"({b:.1f} ч vs {a:.1f} ч) — возможно, индивидуальная норма."
        ),
        "Недостаточно данных о сне для вывода.",
    )

    return (
        "🔍 Мои инсайты\n\n"
        f"📅 Дни недели и настроение\n{i1}\n\n"
        f"💼 Работа/учёба и настроение\n{i2}\n\n"
        f"😴 Сон и продуктивность\n{i3}"
    )


def generate_chart(user_id: int) -> io.BytesIO | None:
    data = [dict(r) for r in get_records_between(user_id, *period_dates(7))]
    if not data:
        return None

    dates = [date.fromisoformat(r["date"]) for r in data]
    moods = [r["mood"] for r in data]
    sleep = [r["sleep_hours"] for r in data]
    work = [r["work_hours"] for r in data]
    x = range(len(dates))

    fig, ax1 = plt.subplots(figsize=(10, 5))
    ax1.plot(x, moods, marker="o", color="tab:blue", label="Настроение")
    ax1.set_ylim(0.5, 5.5)
    ax1.set_xticks(x)
    ax1.set_xticklabels([d.strftime("%d.%m") for d in dates], rotation=45)
    ax1.grid(True, alpha=0.3)

    ax2 = ax1.twinx()
    ax2.plot(x, sleep, marker="s", color="tab:green", linestyle="--", label="Сон")
    ax2.plot(x, work, marker="^", color="tab:orange", linestyle="--", label="Работа")

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="upper left")
    plt.title("Настроение, сон и работа — последние 7 дней")
    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format="png", dpi=120)
    buf.seek(0)
    plt.close(fig)
    return buf


def format_history_entry(row) -> str:
    r = dict(row)
    d = date.fromisoformat(r["date"]).strftime("%d.%m.%Y")
    line = (
        f"📅 {d}\n"
        f"  Настроение: {MOOD_EMOJI.get(r['mood'], '')} ({r['mood']}/5)\n"
        f"  Работа: {r['work_hours']} ч | Сон: {r['sleep_hours']} ч"
    )
    return line + (f"\n  💬 {r['comment']}" if r.get("comment") else "")
